#include <iostream>
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

enum hasloEnum {
    tak = 1,
    nie = 2
};
void show(int tmp);

struct Haslo;
namespace Files {
    class File {
    private:
        char x[256];
        ofstream ostream;
        fstream fin;
        bool tmp;
        char ch1, ch;
        vector<int> v1;

    public:

        void saveFile(string wrt,string user) {


            int tmp = wrt.length();

           if(user=="maciek") {
               ostream.open("C:\\Users\\Franek\\CLionProjects\\Projekt_cpp\\haslaUser1", ios_base::app);
           }else if(user=="karol"){
               ostream.open("C:\\Users\\Franek\\CLionProjects\\Projekt_cpp\\haslaUser2", ios_base::app);
           }else if(user=="czarek"){
               ostream.open("C:\\Users\\Franek\\CLionProjects\\Projekt_cpp\\haslaUser3", ios_base::app);
           }
            for (int i = 0; i <= tmp; i++) {


                if (v1.size() < tmp) {
                    ostream << (char) (wrt[i] + 3);
                }else
                    ostream << "\n";
                v1.push_back(i);
            }

            ostream.close();
        }

        void readFile(string user) {


            int count=0;
            if(user=="maciek") {
                fin.open("C:\\Users\\Franek\\CLionProjects\\Projekt_cpp\\haslaUser1", fstream::in);
            }else if(user=="karol"){
                fin.open("C:\\Users\\Franek\\CLionProjects\\Projekt_cpp\\haslaUser2", fstream::in);
            }else if(user=="czarek"){
                fin.open("C:\\Users\\Franek\\CLionProjects\\Projekt_cpp\\haslaUser3", fstream::in);
            }
            while (fin >> noskipws >> ch) {
                if (ch > 47 && ch < 128) {
                    cout << (char) (ch - 3);
                } else if (ch == 10) {
                    cout << "\n";
                    count++;
                }
            }
            fin.close();

        }

    };
}
void show(int tmp,string user){
    string newHaslo;
    Files::File f4;

    if (tmp == hasloEnum(tak) ) {
        cout<<"Dopisz haslo: "<<endl;
        cin>>newHaslo;
        f4.saveFile(newHaslo,user);
    } else
        cout<<"Nie dopisane zostanie zadne haslo."<<endl;
}
void coZrobic(string user) {
    int wrt, tmp = 1;
    Files::File f2;
    cout << "Co chcesz zrobic? " << endl;
    cout << "1.Zapis nowego hasla. \n2.Odczyt wszystkich hasel\n3.Wyjscie." << endl;

    while (wrt != 3) {

        cin >> wrt;
        switch (wrt) {
            case 1:
             show(tmp,user);
             break;
            case 2:
              f2.readFile(user);
              break;
            case 3:
             exit(0);
            default:
                cout<<"Zly numer"<<endl;
                exit(0);
        }
    }
}

struct Haslo {
public:
    string user1Pass = "qwe123";
    string user1="maciek";
    string user2Pass = "asd123";
    string user2="karol";
    string user3Pass = "zxc123";
    string user3="czarek";

};


void checkHaslo(string userPass,string user) {
    Haslo h1;
    Files::File f1;

    int counter=0;

    if ((userPass == h1.user1Pass) && (user == h1.user1)) {
        coZrobic(user);
    } else if ((userPass == h1.user1Pass) || (user == h1.user1)) {
        if(counter==0)
            cout << "Zle haslo lub login.";
        counter++;
    }



    if ((userPass == h1.user2Pass) && (user == h1.user2)) {
        coZrobic(user);
    } else if ((userPass == h1.user2Pass) || (user == h1.user2)) {
        if(counter==0)
            cout << "Zle haslo lub login.";
        counter++;
    }

    if ((userPass == h1.user3Pass) && (user == h1.user3)) {
        coZrobic(user);
    } else if ((userPass == h1.user3Pass) || (user == h1.user3)) {
        if(counter==0)
            cout << "Zle haslo lub login.";
        counter++;
    }


}

void writeHaslo(string user) {
    string userPass;
    cout << "Wpisz haslo: " << endl;
    cin >> userPass;

    checkHaslo(userPass,user);
}



int main() {
    string user;

    cout << "Podaj login: " << endl;
    cin >> user;
    writeHaslo(user);


    return 0;
}

